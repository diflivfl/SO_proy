function [A1,A2,f1,f2] = DTMF (x)
fs = 8000;
N = 1024;

X = fft(x, N);
[d1,k1] = max(abs(X(1:N/2)));

X(k1)=0;
[d2,k2] = max(abs(X(1:N/2)));

f1 = k1*fs/N;
f2 = k2 * fs /N;

A1= d1*2/N;
A2= d2*2/N;

end