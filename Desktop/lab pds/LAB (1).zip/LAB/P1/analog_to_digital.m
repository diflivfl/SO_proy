function [x] = analog_to_digital(t,fs)
te = audiorecorder(fs, 16, 2);
recordblocking(te, t);
x = getaudiodata(te);

end