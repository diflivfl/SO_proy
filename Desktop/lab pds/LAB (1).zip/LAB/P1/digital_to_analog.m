function [] = digital_to_analog(x,fs)

soundsc(x,fs);

end