function [s] = simple_echo_equalitzation(y, alpha, fs, delay)

L=length(y);

D = round(delay*fs);

s = zeros(L,1);

    for n=1:1:L
        if n<=D
            s(n) = y(n);
        elseif n>D
            s(n) = y(n) -alpha*s(n-D);
        end
    end

end