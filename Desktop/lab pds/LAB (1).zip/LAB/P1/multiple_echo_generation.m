function [y] = multiple_echo_generation(x1, alpha, fs, delay)

L=length(x1);

D = round(delay*fs);

y = zeros(L,1);

    for n=1:1:L
        if n<=D
            y(n) = x1(n);
        elseif n>D
            y(n) = x1(n) +alpha*y(n-D);
        end
    end

end