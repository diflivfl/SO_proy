function [h] = multiple_echo_equalization(y, alpha, fs, delay)

L=length(y);

D = round(delay*fs);

h = zeros(L,1);

    for n=1:1:L
        if n<=D
            h(n) = y(n);
        elseif n>D
            g(n) = y(n) -alpha*y(n-D);
        end
    end

end